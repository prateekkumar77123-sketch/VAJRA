@echo off
title VAJRA Drone Intrusion Detection System
color 0B
echo ======================================================================
echo           VAJRA Drone IDS & Blockchain Forensics Console
echo           PUSHPAK Grand Challenge 2026 - Objective 2
echo ======================================================================
echo.
echo [1/3] Verifying Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python 3.10+ from python.org and check "Add Python to PATH".
    pause
    exit /b
)

echo [2/3] Checking dependencies...
pip install -r requirements.txt
if errorlevel 1 (
    echo [WARNING] Some dependencies failed to install. Continuing...
)

echo.
echo [3/3] Launching VAJRA Backend & Opening Console in browser...
start "" "http://localhost:8000"
python backend\app.py

pause
