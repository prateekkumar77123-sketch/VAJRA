# VAJRA Drone IDS — Demonstration Video Script & Walkthrough
**PUSHPAK Grand Challenge 2026: Security of Drones (Objective 2)**  
*Stage 1 Preliminary Design Verification Video Protocol (3–5 Minutes)*

---

## 🎬 Video Recording Setup (Recommended)
1. **Screen Recorder**: Use OBS Studio, Windows Game Bar (`Win + G`), or simple screen recorder at 1080p 60fps.
2. **Screen Layout**:
   - Left half: Web Browser showing **`http://localhost:8000`** (VAJRA Drone IDS Console).
   - Right half: Terminal running **`python demonstration.py`** (or let the automated runner drive the UI).
3. **Audio**: Clean microphone narration using the script below.

---

## 🎙️ Exact Voiceover Script & Timecoded Sequence

### [0:00 – 0:35] Part 1: Problem Statement & Architecture
> **Narrator**:  
> *"Hello respected evaluators and jury members of IIT Bombay and VJTI. Welcome to the Stage 1 demonstration of project **VAJRA**, our indigenous Real-Time Drone Intrusion Detection System and Blockchain Forensics Ledger, designed for Objective 2 of the PUSHPAK Grand Challenge 2026.*  
>  
> *Modern UAVs rely on unencrypted MAVLink and vulnerable GNSS signals. VAJRA introduces a lightweight, low-compute cyber defence pipeline capable of running on a Raspberry Pi 5 companion computer attached to an ArduPilot flight controller. It uses a two-stage hybrid ensemble: deterministic explainable rules, unsupervised Isolation Forest anomaly detection, and supervised Random Forest attack classification, backed by a cryptographic Merkle-tree blockchain."*

---

### [0:35 – 1:15] Part 2: Nominal Flight & System Initialization
> **Action**: Run `python demonstration.py`. Show the browser opening to the **Overview** & **Live Flight** tabs.  
>  
> **Narrator**:  
> *"Here we see our backend initialized. The passive MAVLink adapter ingests standard MAVLink 2.0 messages at 1 Hz, extracting a 19-dimensional kinematic, communication, and sensor-consistency feature vector.*  
>  
> *Under nominal cruising conditions, our ground speed, altitude, and MAVLink throughput remain within normal dynamic bounds. The IDS status shows green and nominal, with an ultra-low baseline False Positive Rate of 0.00% across our benchmark flights, completely eliminating false operator alarms."*

---

### [1:15 – 2:05] Part 3: Live Attack Injections (GPS Spoofing, DoS, Command Injection)
> **Action**: Click or show the script triggering **⚡ GPS Spoofing**, then **⚡ MAVLink DoS**, then **⚡ Command Injection**.  
>  
> **Narrator**:  
> *"Now let us trigger representative attack scenarios:*  
>  
> *1. First, **GPS Spoofing**: An abrupt 250-meter coordinate teleportation is injected. Within **0.23 milliseconds**, our rule engine and ML classifier detect kinematic divergence between reported speed and derived trajectory displacement, raising a CRITICAL alert.*  
>  
> *2. Next, **MAVLink DoS Flooding**: The message rate surges to 195 Hz with 28% packet loss. VAJRA immediately isolates the communication disruption.*  
>  
> *3. Third, **Command Injection**: High-frequency spurious MAV_CMD override frames outside the authorized mission plan are intercepted instantly.*  
>  
> *Notice that for every alert, VAJRA generates not just a black-box AI score, but full before-and-after evidence deltas."*

---

### [2:05 – 2:45] Part 4: Blockchain Forensics & Tamper Proofing
> **Action**: Switch to the **⛓ Blockchain Ledger** tab and click **"Run Immutability Tamper Test"**.  
>  
> **Narrator**:  
> *"Evidence preservation is critical for post-incident investigation. Every flagged intrusion and telemetry digest is serialized, hashed with SHA-256, and aggregated into a binary **Merkle Tree Root** on our lightweight Consortium Blockchain.*  
>  
> *Here we demonstrate our cryptographic tamper-detection test: If an attacker modifies even a single byte of historical telemetry on Block #1, our validation algorithm instantly catches the Merkle root divergence and invalidates the chain, ensuring legally defensible chain of custody."*

---

### [2:45 – 3:20] Part 5: Benchmark Scorecard & Conclusion
> **Action**: Switch back to Overview / display terminal benchmark summary.  
>  
> **Narrator**:  
> *"In summary, VAJRA achieves:*  
> *- **100% Detection Accuracy** across all attack vectors.*  
> *- **0.00% False Positive Rate** on unseen test evaluations.*  
> *- **0.231 ms Average Detection Latency**, operating at over 4,300 packets per second.*  
> *- **3.37 kilometers of continuous flight tracking** verified.*  
>  
> *The entire system runs cross-platform on Windows and Linux, ready for deployment on companion computers in Stage 2. Thank you."*
