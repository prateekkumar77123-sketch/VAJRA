#!/usr/bin/env bash
# ==============================================================================
# VAJRA Drone IDS Launcher for Linux (Ubuntu / Debian / Raspberry Pi OS)
# PUSHPAK Grand Challenge 2026 - Objective 2 (IIT Bombay / VJTI)
# ==============================================================================

set -e

echo "======================================================================"
echo "          VAJRA Drone IDS & Blockchain Forensics Console"
echo "======================================================================"

# 1. Check Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] python3 could not be found. Please install Python 3.10+."
    exit 1
fi

echo "[1/3] Python detected: $(python3 --version)"

# 2. Install dependencies
echo "[2/3] Checking requirements..."
pip3 install -r requirements.txt || true

# 3. Start Backend & Open Browser
echo "[3/3] Launching VAJRA Backend on http://127.0.0.1:8000 ..."
if command -v xdg-open &> /dev/null; then
    xdg-open "http://127.0.0.1:8000" &
elif command -v open &> /dev/null; then
    open "http://127.0.0.1:8000" &
fi

python3 backend/app.py
