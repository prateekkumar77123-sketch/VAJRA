"""
Blockchain Forensics and Evidence Integrity Ledger for VAJRA Drone IDS
Implements a tamper-evident cryptographic blockchain with Merkle Trees,
Proof-of-Work / Proof-of-Authority anchoring, and cryptographic chain validation.
"""

import hashlib
import json
import time
from typing import List, Dict, Any, Tuple, Optional
from pathlib import Path

class MerkleTree:
    """
    Constructs a Merkle Tree from a list of serialized records to produce a tamper-evident root hash.
    """
    @staticmethod
    def hash_pair(left: str, right: str) -> str:
        combined = (left + right).encode('utf-8')
        return hashlib.sha256(combined).hexdigest()

    @classmethod
    def compute_root(cls, leaves: List[str]) -> str:
        if not leaves:
            return hashlib.sha256(b"EMPTY_MERKLE_ROOT").hexdigest()
        
        current_level = [hashlib.sha256(leaf.encode('utf-8')).hexdigest() for leaf in leaves]
        
        while len(current_level) > 1:
            next_level = []
            for i in range(0, len(current_level), 2):
                left = current_level[i]
                right = current_level[i + 1] if i + 1 < len(current_level) else left
                next_level.append(cls.hash_pair(left, right))
            current_level = next_level

        return current_level[0]

class Block:
    def __init__(
        self,
        index: int,
        timestamp: float,
        previous_hash: str,
        records: List[Dict[str, Any]],
        nonce: int = 0,
        block_hash: Optional[str] = None,
        validator: str = "VAJRA-AIRFRAME-UAV-01"
    ):
        self.index = index
        self.timestamp = timestamp
        self.previous_hash = previous_hash
        self.records = records
        self.validator = validator
        self.nonce = nonce
        
        # Serialize records for Merkle Tree computation
        serialized_records = [json.dumps(r, sort_keys=True) for r in records]
        self.merkle_root = MerkleTree.compute_root(serialized_records)
        self.hash = block_hash or self.calculate_hash()

    def calculate_hash(self) -> str:
        header = f"{self.index}{self.timestamp}{self.previous_hash}{self.merkle_root}{self.nonce}{self.validator}"
        return hashlib.sha256(header.encode('utf-8')).hexdigest()

    def mine_block(self, difficulty: int = 2) -> Tuple[str, int]:
        target = "0" * difficulty
        while not self.hash.startswith(target):
            self.nonce += 1
            self.hash = self.calculate_hash()
        return self.hash, self.nonce

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "time_iso": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(self.timestamp)),
            "previous_hash": self.previous_hash,
            "merkle_root": self.merkle_root,
            "records_count": len(self.records),
            "records": self.records,
            "nonce": self.nonce,
            "hash": self.hash,
            "validator": self.validator
        }

class BlockchainLedger:
    """
    Decentralized Forensics Ledger for Drone Security Events and Flight Black-Box Telemetry.
    """
    def __init__(self, difficulty: int = 2, ledger_path: Optional[Path] = None):
        self.difficulty = difficulty
        self.ledger_path = ledger_path
        self.chain: List[Block] = []
        self.pending_records: List[Dict[str, Any]] = []
        self._init_chain()

    def _init_chain(self):
        if self.ledger_path and self.ledger_path.exists():
            self.load_from_disk()
        else:
            # Create Genesis Block
            genesis_record = [{
                "event_type": "GENESIS_INITIALIZATION",
                "system": "VAJRA Drone IDS Security Backbone",
                "mission_id": "MISSION-IITB-2026",
                "timestamp": time.time(),
                "status": "SECURE_BOOT"
            }]
            genesis = Block(
                index=0,
                timestamp=time.time(),
                previous_hash="0" * 64,
                records=genesis_record,
                nonce=0
            )
            genesis.mine_block(self.difficulty)
            self.chain.append(genesis)
            self.save_to_disk()

    @property
    def latest_block(self) -> Block:
        return self.chain[-1]

    def add_evidence_record(self, record: Dict[str, Any], auto_mine: bool = True) -> Dict[str, Any]:
        """
        Appends a security event or forensic evidence item. If auto_mine is True,
        mines immediately or packages into the current block.
        """
        import copy
        record_copy = copy.deepcopy(record)
        record_id = record.get("event_id", f"rec_{int(time.time()*1000)}")
        record_copy["blockchain_ingest_ts"] = time.time()
        record_serialized = json.dumps(record_copy, sort_keys=True)
        record_sha256 = hashlib.sha256(record_serialized.encode('utf-8')).hexdigest()
        record_copy["sha256"] = record_sha256

        self.pending_records.append(record_copy)

        block_result = None
        if auto_mine or len(self.pending_records) >= 5:
            block = Block(
                index=len(self.chain),
                timestamp=time.time(),
                previous_hash=self.latest_block.hash,
                records=list(self.pending_records),
                validator="VAJRA-COMPANION-RPi5"
            )
            block.mine_block(self.difficulty)
            self.chain.append(block)
            self.pending_records.clear()
            self.save_to_disk()
            block_result = block.to_dict()

        return {
            "record_id": record_id,
            "sha256": record_sha256,
            "status": "anchored" if block_result else "queued",
            "block_index": self.latest_block.index,
            "block_hash": self.latest_block.hash,
            "tx_ref": f"0x{record_sha256[:16]}...anchor",
            "chain": "VAJRA-Consortium-Ledger",
            "anchored_at": int(time.time() * 1000)
        }

    def validate_chain(self) -> Dict[str, Any]:
        """
        Validates the entire blockchain from genesis to tip.
        Verifies previous_hash links, recomputed block hashes, Merkle roots, and PoW constraints.
        """
        for i in range(1, len(self.chain)):
            curr = self.chain[i]
            prev = self.chain[i - 1]

            # 1. Verify previous hash pointer
            if curr.previous_hash != prev.hash:
                return {
                    "valid": False,
                    "error_type": "BROKEN_LINK",
                    "block_index": i,
                    "expected_prev_hash": prev.hash,
                    "actual_prev_hash": curr.previous_hash
                }

            # 2. Verify Merkle root integrity
            serialized_records = [json.dumps(r, sort_keys=True) for r in curr.records]
            recomputed_merkle = MerkleTree.compute_root(serialized_records)
            if curr.merkle_root != recomputed_merkle:
                return {
                    "valid": False,
                    "error_type": "MERKLE_ROOT_TAMPERED",
                    "block_index": i,
                    "expected_merkle": recomputed_merkle,
                    "actual_merkle": curr.merkle_root
                }

            # 3. Verify block hash calculation
            if curr.hash != curr.calculate_hash():
                return {
                    "valid": False,
                    "error_type": "HASH_CORRUPTION",
                    "block_index": i,
                    "expected_hash": curr.calculate_hash(),
                    "actual_hash": curr.hash
                }

            # 4. Verify Proof of Work
            target = "0" * self.difficulty
            if not curr.hash.startswith(target):
                return {
                    "valid": False,
                    "error_type": "PROOF_OF_WORK_INVALID",
                    "block_index": i,
                    "total_blocks": len(self.chain)
                }

        return {
            "valid": True,
            "total_blocks": len(self.chain),
            "total_records": sum(len(b.records) for b in self.chain),
            "tip_hash": self.latest_block.hash
        }

    def simulate_tamper(self, block_index: int, key: str, new_value: Any) -> Dict[str, Any]:
        """
        Deliberately modifies an on-chain record to demonstrate tamper detection in tests.
        """
        if 0 <= block_index < len(self.chain):
            b = self.chain[block_index]
            if b.records:
                b.records[0][key] = new_value
                return {"status": "tampered", "block_index": block_index, "modified_key": key}
        return {"status": "failed", "reason": "block not found"}

    def save_to_disk(self):
        if self.ledger_path:
            self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
            data = [b.to_dict() for b in self.chain]
            with open(self.ledger_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

    def load_from_disk(self):
        if self.ledger_path and self.ledger_path.exists():
            with open(self.ledger_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.chain = [
                Block(
                    index=d["index"],
                    timestamp=d["timestamp"],
                    previous_hash=d["previous_hash"],
                    records=d["records"],
                    nonce=d["nonce"],
                    block_hash=d["hash"],
                    validator=d.get("validator", "VAJRA-AIRFRAME")
                )
                for d in data
            ]
