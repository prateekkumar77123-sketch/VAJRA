"""
Live Attack Injector Utility for VAJRA Drone IDS
Used for live jury demonstrations and test scenarios (TC-01 to TC-06).
Sends commands directly to the running backend to simulate live in-flight cyberattacks.
"""

import sys
import time
import argparse
import requests

def inject_attack(scenario: str, backend_url: str = "http://localhost:8000"):
    print(f"[*] Triggering Attack Scenario: {scenario.upper()} on {backend_url}")
    try:
        r = requests.post(f"{backend_url}/api/simulate/attack?scenario={scenario}", timeout=2.0)
        if r.status_code == 200:
            print(f"[✔] Attack successfully injected: {scenario}")
            print("[*] Monitoring backend response for 5 seconds...")
            for i in range(5):
                time.sleep(1.0)
                status_r = requests.get(f"{backend_url}/api/status", timeout=1.0)
                alerts_r = requests.get(f"{backend_url}/api/alerts", timeout=1.0)
                status = status_r.json()
                alerts = alerts_r.json()
                latest_alert = alerts[0] if alerts else None
                print(f"  T+{i+1}s -> IDS Status: {status.get('status')} | Latest Alert: {latest_alert.get('category') if latest_alert else 'none'} (Sev: {latest_alert.get('severity') if latest_alert else 'none'})")
        else:
            print(f"[✖] Failed to inject attack: HTTP {r.status_code}")
    except Exception as e:
        print(f"[✖] Error connecting to backend: {e}")

def reset_normal(backend_url: str = "http://localhost:8000"):
    try:
        r = requests.post(f"{backend_url}/api/simulate/reset", timeout=2.0)
        print("[✔] Reset flight telemetry to NOMINAL status.")
    except Exception as e:
        print(f"[✖] Error connecting to backend: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="VAJRA Attack Scenario Injector")
    parser.add_argument("scenario", choices=["gps_spoofing", "mavlink_dos", "command_injection", "telemetry_manipulation", "gps_quality_anomaly", "reset"], help="Attack scenario to trigger")
    parser.add_argument("--url", default="http://localhost:8000", help="Backend base URL")
    args = parser.parse_args()

    if args.scenario == "reset":
        reset_normal(args.url)
    else:
        inject_attack(args.scenario, args.url)
