# VAJRA Drone IDS — System Architecture & Algorithmic Blueprint

## Overview
**VAJRA** (Real-Time Drone Intrusion Detection System & Blockchain Forensics Ledger) is developed for the **PUSHPAK Grand Challenge 2026: Security of Drones (Objective 2)**, hosted by **IIT Bombay** in collaboration with **VJTI Mumbai** and funded by the **Ministry of Electronics and Information Technology (MeitY)**.

The system continuously monitors UAV communication channels, navigation telemetry, attitude kinematics, control commands, and sensor integrity in real time. It operates autonomously with ultra-low latency (<0.3 ms) and minimal memory overhead (<1 MB model footprint), making it ideal for edge deployment on a **Raspberry Pi 5** or Jetson companion computer attached to an ArduPilot/PX4 flight controller.

---

## 1. High-Level Architecture

```mermaid
flowchart TD
    subgraph Data Acquisition & Parsing
        UAV[UAV Flight Controller / ArduPilot SITL] -->|MAVLink 2.0 / UDP / Serial| MCP[MAVLink Collector & Adapter]
        MCP -->|Raw Packets| NP[Normalization & State Tracking]
    end

    subgraph Feature Engineering
        NP -->|1 Hz Normal Telemetry| SWB[Sliding Time-Window Buffer N=5]
        SWB -->|Compute Deltas| FE[Kinematic & Security Feature Extractor]
    end

    subgraph Two-Stage Hybrid Detection Engine
        FE -->|Feature Vector| RE[Deterministic Rule Engine]
        FE -->|Scaled Features| S1[Stage 1: Isolation Forest Anomaly Detector]
        RE -->|Explainable Violations| COR[Correlation & Decision Engine]
        S1 -->|Anomaly Score in 0..1| COR
        COR -->|If Anomalous| S2[Stage 2: Random Forest Multi-Class Classifier]
    end

    subgraph Output & Defense Layer
        S2 -->|Predicted Attack & Confidence| ALM[Alert Engine & Severity Ranker]
        ALM -->|Real-Time Broadcast| WS[WebSocket Streaming /ws/telemetry]
        ALM -->|REST APIs| FAST[FastAPI Backend]
        FAST -->|Live Visuals| UI[VAJRA Web IDS Console]
    end

    subgraph Cryptographic Forensics & Blockchain
        ALM -->|Evidence Payload| MRK[Merkle Tree Root Computer]
        MRK -->|Chained SHA-256| POW[Proof-of-Work Consensus Engine]
        POW -->|Mined Blocks| BLK[(Immutable Blockchain Ledger)]
    end
```

---

## 2. Algorithmic Pipeline

### Step 1: Passive Ingestion & Parsing
- Listens passively on serial UART `/dev/ttyAMA0` or UDP `127.0.0.1:14550`.
- Decodes standard MAVLink messages:
  - `GLOBAL_POSITION_INT` (Lat, Lon, Alt, Groundspeed, Heading)
  - `GPS_RAW_INT` (Satellites visible, Fix type, HDOP)
  - `ATTITUDE` (Roll, Pitch, Yaw, Angular velocity rates)
  - `SYS_STATUS` (Battery voltage, Current draw, Comm packet drop rate)
  - `COMMAND_LONG` (Injected command count and frequency)

### Step 2: Temporal Feature Extraction
Extracts 19 compact security and physical features over a sliding window:
1. `ground_speed_mps`: Sensor-reported ground speed.
2. `altitude_m`: Barometric / GPS altitude.
3. `vertical_speed_mps`: \(\frac{\Delta alt}{\Delta t}\).
4. `gps_displacement_m`: Haversine distance between consecutive GPS coordinates.
5. `speed_vs_displacement_diff`: \(|v_{reported} - \frac{d_{haversine}}{\Delta t}|\).
6. `angular_rate_magnitude`: \(\sqrt{\omega_{roll}^2 + \omega_{pitch}^2 + \omega_{yaw}^2}\).
7. `satellites_visible`: Active satellite constellation count.
8. `gps_fix_type`: 3D, 2D, or no lock.
9. `battery_voltage_drop_rate`: \(\frac{\Delta V}{\Delta t}\).
10. `mavlink_message_rate_hz`: Incoming packet throughput.
11. `message_rate_delta`: Packet rate gradient.
12. `packet_loss_percent`: Ratio of dropped MAVLink frames.
13. `command_rate_hz`: Uplink command frequency.
14. `command_rate_spike`: Sudden burst of control commands.

### Step 3: Two-Stage Hybrid Classification
1. **Rule Engine**: Provides explainable, non-probabilistic checks for physical impossibilities:
   - GPS coordinate jump > 20 m/s without matching acceleration.
   - MAVLink packet rate > 120 Hz or loss > 15%.
   - Command frequency > 2.0 Hz outside authorized mission sequence.
   - Vertical climb > 8 m/s or ground speed < 0.5 m/s with 30 m displacement.
   - Satellite count < 8 or loss of 3D lock.
2. **Stage 1 (Isolation Forest)**:
   - Detects unknown / out-of-distribution cyber anomalies based on normal flight baseline.
   - Produces continuous anomaly score \(S_{anomaly} \in [0.0, 1.0]\).
3. **Stage 2 (Random Forest Multi-Class Classifier)**:
   - Classifies detected anomalies into precise threat vectors with class confidence:
     - `gps_spoofing`
     - `mavlink_dos`
     - `command_injection`
     - `telemetry_manipulation`
     - `gps_quality_anomaly`
     - `firmware_param_tamper`

---

## 3. Blockchain Forensics Algorithm

To ensure **legally defensible digital evidence** and adhere to chain-of-custody standards:
1. **Merkle Trees**: Every batch of telemetry snapshots and intrusion alerts is organized into a binary Merkle tree.
2. **SHA-256 Chained Blocks**: Each block stores:
   \[
   H_n = \text{SHA-256}(\text{Index} \parallel \text{Timestamp} \parallel H_{n-1} \parallel \text{MerkleRoot} \parallel \text{Nonce} \parallel \text{Validator})
   \]
3. **Proof-of-Work / Authority**: Prevents retroactive ledger rewrite.
4. **Tamper Detection**: The validation function recomputes every block hash and Merkle root. Any single-byte modification in historical telemetry causes immediate chain invalidation and identifies the exact compromised block.
