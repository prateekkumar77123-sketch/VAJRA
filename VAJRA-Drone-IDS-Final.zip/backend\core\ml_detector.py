"""
Stage 1 ML Anomaly Detector for VAJRA Drone IDS
Implements Isolation Forest for lightweight, low-compute anomaly detection.
"""

from pathlib import Path
import numpy as np
import joblib
from typing import Tuple, Optional

class AnomalyDetector:
    def __init__(self, model_path: Optional[Path] = None, scaler_path: Optional[Path] = None):
        self.model_path = model_path
        self.scaler_path = scaler_path
        self.model = None
        self.scaler = None
        if model_path and model_path.exists() and scaler_path and scaler_path.exists():
            self.load(model_path, scaler_path)

    def load(self, model_path: Path, scaler_path: Path):
        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)

    def is_loaded(self) -> bool:
        return self.model is not None and self.scaler is not None

    def predict(self, feature_vector: np.ndarray) -> Tuple[bool, float]:
        """
        Runs Stage 1 inference.
        Returns: (is_anomaly, normalized_anomaly_score in [0.0, 1.0])
        """
        if not self.is_loaded():
            # Fallback if model not trained yet
            return False, 0.1

        scaled_vec = self.scaler.transform(feature_vector)
        # decision_function gives negative score for outliers, positive for inliers
        raw_score = self.model.decision_function(scaled_vec)[0]
        # Normalize into 0..1 where 1.0 is extremely anomalous
        # Typical range of IsolationForest decision_function is [-0.5, 0.5]
        anomaly_score = float(np.clip(0.5 - raw_score, 0.0, 1.0))
        is_anomaly = anomaly_score >= 0.55
        return is_anomaly, anomaly_score
