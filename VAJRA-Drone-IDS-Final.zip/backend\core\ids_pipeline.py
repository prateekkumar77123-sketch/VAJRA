"""
End-to-End Hybrid Intrusion Detection Pipeline for VAJRA Drone IDS
Integrates Rule Engine, Stage 1 Anomaly Detection, Stage 2 Classification,
and Blockchain Forensics Anchoring.
"""

import time
import math
from typing import Dict, Any, Optional, List
from pathlib import Path
import numpy as np

from .config import CONFIG
from .feature_extractor import FeatureExtractor
from .rule_engine import RuleEngine
from .ml_detector import AnomalyDetector
from .ml_classifier import AttackClassifier
from .blockchain import BlockchainLedger

class IDSPipeline:
    def __init__(self, models_dir: Path, ledger_path: Path):
        self.config = CONFIG
        self.feature_extractor = FeatureExtractor(window_size=self.config.WINDOW_SIZE)
        self.rule_engine = RuleEngine(config=self.config)
        
        # Load ML components
        scaler_p = models_dir / "scaler.joblib"
        stage1_p = models_dir / "isolation_forest.joblib"
        stage2_p = models_dir / "attack_classifier.joblib"
        self.stage1_detector = AnomalyDetector(stage1_p, scaler_p)
        self.stage2_classifier = AttackClassifier(stage2_p, scaler_p)

        # Initialize Blockchain forensics ledger
        self.blockchain = BlockchainLedger(difficulty=self.config.BLOCKCHAIN_DIFFICULTY, ledger_path=ledger_path)

        self.event_counter = 1
        self.active_alerts: List[Dict[str, Any]] = []
        self.recent_packets: List[Dict[str, Any]] = []
        self.last_before_snapshot = None

    def process_packet(self, packet: Dict[str, Any]) -> Dict[str, Any]:
        """
        Processes a single telemetry frame through the complete IDS pipeline.
        """
        start_time = time.perf_counter()

        # Step 1: Feature Extraction
        features = self.feature_extractor.extract_features(packet)
        feat_vector = self.feature_extractor.to_feature_vector(features)
        
        # Step 2: Deterministic Rule Checks
        rule_result = self.rule_engine.evaluate(packet, features)

        # Step 3: Stage 1 ML Anomaly Detection
        is_ml_anomaly, anomaly_score = self.stage1_detector.predict(feat_vector)

        # Step 4: Decision & Correlation
        is_threat = (rule_result is not None and rule_result.is_violation) or (anomaly_score >= self.config.STAGE1_ANOMALY_THRESHOLD)

        category = "nominal"
        severity = "none"
        confidence_scale = min(9.0, max(1.0, anomaly_score * 9.0))
        stage1_conf = anomaly_score
        stage2_conf = 0.0
        evidence_list = []
        alert_event = None

        if is_threat:
            # Step 5: Stage 2 Attack Classification
            pred_cat, cat_prob, all_probs = self.stage2_classifier.classify(feat_vector)
            
            # Prioritize rule category if clear deterministic violation exists
            if rule_result and rule_result.is_violation:
                category = rule_result.category
                severity = rule_result.severity
                evidence_list.extend(rule_result.evidence)
                stage2_conf = max(cat_prob, 0.88)
            else:
                category = pred_cat if pred_cat != "none" else "abnormal_flight"
                severity = "critical" if cat_prob > 0.8 else "warning"
                stage2_conf = cat_prob
                evidence_list.append(f"Stage 1 ML anomaly deviation score {anomaly_score:.2f} exceeds nominal bounds")
                evidence_list.append(f"Stage 2 classifier matched pattern: {category} with {cat_prob*100:.1f}% confidence")

            confidence_scale = min(9.0, max(5.0, ((stage1_conf + stage2_conf) / 2.0) * 9.0))

            # Step 6: Create Alert and Anchor into Blockchain
            event_id = f"evt_{str(self.event_counter).zfill(4)}"
            self.event_counter += 1

            before_snap = self.last_before_snapshot or {
                "lat": packet["latitude_deg"],
                "lon": packet["longitude_deg"],
                "alt": round(packet["altitude_m"], 1),
                "spd": round(packet["ground_speed_mps"], 1),
                "hdg": round(packet["heading_deg"], 0),
                "rate": round(packet.get("mavlink_message_rate_hz", 48.0), 0),
                "sig": round(packet.get("rssi_dbm", -55.0), 0),
                "sats": int(packet.get("satellites_visible", 14)),
                "conf": round(confidence_scale, 1)
            }

            after_snap = {
                "lat": packet["latitude_deg"],
                "lon": packet["longitude_deg"],
                "alt": round(packet["altitude_m"], 1),
                "spd": round(packet["ground_speed_mps"], 1),
                "hdg": round(packet["heading_deg"], 0),
                "rate": round(packet.get("mavlink_message_rate_hz", 48.0), 0),
                "sig": round(packet.get("rssi_dbm", -55.0), 0),
                "sats": int(packet.get("satellites_visible", 14)),
                "conf": round(confidence_scale, 1)
            }

            alert_event = {
                "id": event_id,
                "category": category,
                "severity": severity,
                "state": "open",
                "ts": int(time.time() * 1000),
                "time": time.strftime("%H:%M:%S"),
                "stage1": round(stage1_conf, 2),
                "stage2": round(stage2_conf, 2),
                "evidence": evidence_list,
                "before": before_snap,
                "after": after_snap
            }

            # Blockchain Anchoring
            anchor_res = self.blockchain.add_evidence_record(alert_event, auto_mine=True)
            alert_event["blockchain"] = anchor_res

            self.active_alerts.insert(0, alert_event)
            if len(self.active_alerts) > 100:
                self.active_alerts.pop()
        else:
            # Nominal snapshot storage
            self.last_before_snapshot = {
                "lat": packet["latitude_deg"],
                "lon": packet["longitude_deg"],
                "alt": round(packet["altitude_m"], 1),
                "spd": round(packet["ground_speed_mps"], 1),
                "hdg": round(packet["heading_deg"], 0),
                "rate": round(packet.get("mavlink_message_rate_hz", 48.0), 0),
                "sig": round(packet.get("rssi_dbm", -55.0), 0),
                "sats": int(packet.get("satellites_visible", 14)),
                "conf": round(confidence_scale, 1)
            }

        elapsed_ms = (time.perf_counter() - start_time) * 1000.0

        result = {
            "timestamp_ms": packet["timestamp_ms"],
            "status": "threat_detected" if is_threat else "nominal",
            "is_anomaly": is_threat,
            "category": category,
            "severity": severity,
            "confidence_score": round(confidence_scale, 1),
            "stage1_anomaly_score": round(stage1_conf, 3),
            "stage2_confidence": round(stage2_conf, 3),
            "evidence": evidence_list,
            "total_distance_m": round(self.feature_extractor.total_distance_m, 1),
            "latency_ms": round(elapsed_ms, 3),
            "new_alert": alert_event
        }
        return result
