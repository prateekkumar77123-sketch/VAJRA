"""
Rule-Based Intrusion Detection Engine for VAJRA Drone IDS
Deterministic physical envelope checks, communication integrity, and explainable rule violations.
"""

from typing import Dict, Any, List, Optional
from .config import CONFIG

class RuleCheckResult:
    def __init__(self, is_violation: bool, rule_id: str, category: str, severity: str, explanation: str, evidence: List[str]):
        self.is_violation = is_violation
        self.rule_id = rule_id
        self.category = category
        self.severity = severity
        self.explanation = explanation
        self.evidence = evidence

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_violation": self.is_violation,
            "rule_id": self.rule_id,
            "category": self.category,
            "severity": self.severity,
            "explanation": self.explanation,
            "evidence": self.evidence
        }

class RuleEngine:
    def __init__(self, config=CONFIG):
        self.config = config

    def evaluate(self, packet: Dict[str, Any], features: Dict[str, float]) -> Optional[RuleCheckResult]:
        """
        Evaluates physical, communication, and navigation rules against current telemetry & features.
        Returns RuleCheckResult if violation detected, else None.
        """
        # Rule 1: GPS Position Teleportation / Kinematic Inconsistency (GPS Spoofing)
        disp = features.get("gps_displacement_m", 0.0)
        speed_diff = features.get("speed_vs_displacement_diff", 0.0)
        if disp > self.config.MAX_GPS_JUMP_METERS_PER_SEC or speed_diff > 12.0:
            evidence = [
                f"GPS position jumped {disp:.1f} m in 1 s (max threshold {self.config.MAX_GPS_JUMP_METERS_PER_SEC} m/s)",
                f"Reported speed diverges from derived trajectory speed by {speed_diff:.1f} m/s"
            ]
            return RuleCheckResult(
                is_violation=True,
                rule_id="RULE-NAV-01",
                category="gps_spoofing",
                severity="critical",
                explanation="Abrupt coordinate jump with kinematic speed/displacement divergence indicates GPS spoofing.",
                evidence=evidence
            )

        # Rule 2: MAVLink Communication Flooding (DoS)
        msg_rate = features.get("mavlink_message_rate_hz", 0.0)
        pkt_loss = features.get("packet_loss_percent", 0.0)
        if msg_rate > self.config.MAX_MAVLINK_RATE_HZ or pkt_loss > self.config.MAX_PACKET_LOSS_PERCENT:
            evidence = [
                f"MAVLink message rate surged to {msg_rate:.1f} Hz (nominal 40-55 Hz)",
                f"Telemetry packet loss reached {pkt_loss:.1f}% (envelope < {self.config.MAX_PACKET_LOSS_PERCENT}%)"
            ]
            return RuleCheckResult(
                is_violation=True,
                rule_id="RULE-COM-01",
                category="mavlink_dos",
                severity="critical",
                explanation="High-frequency telemetry flooding and packet drop rate indicating link exhaustion DoS attack.",
                evidence=evidence
            )

        # Rule 3: Control Command Flooding (Command Injection)
        cmd_rate = features.get("command_rate_hz", 0.0)
        if cmd_rate > self.config.MAX_COMMAND_RATE_HZ:
            evidence = [
                f"Command arrival rate spiked to {cmd_rate:.1f} Hz (nominal < {self.config.MAX_COMMAND_RATE_HZ} Hz)",
                f"Consecutive MAV_CMD messages outside authorized mission waypoint plan"
            ]
            return RuleCheckResult(
                is_violation=True,
                rule_id="RULE-CMD-01",
                category="command_injection",
                severity="critical",
                explanation="Abnormal control command frequency consistent with automated replay or command injection.",
                evidence=evidence
            )

        # Rule 4: Physical Sanity / Telemetry Manipulation
        v_speed = abs(features.get("vertical_speed_mps", 0.0))
        g_speed = features.get("ground_speed_mps", 0.0)
        batt_drop = features.get("battery_voltage_drop_rate", 0.0)
        if v_speed > self.config.MAX_VERTICAL_SPEED_MPS or (g_speed < 0.5 and disp > 15.0) or batt_drop < -0.8:
            evidence = [
                f"Vertical climb/sink rate of {v_speed:.1f} m/s violates quadcopter dynamic limit ({self.config.MAX_VERTICAL_SPEED_MPS} m/s)",
                f"Sensor contradiction: displacement is {disp:.1f} m while reported speed is {g_speed:.1f} m/s"
            ]
            return RuleCheckResult(
                is_violation=True,
                rule_id="RULE-SAN-01",
                category="telemetry_manipulation",
                severity="warning",
                explanation="Mutually inconsistent sensor values indicating sensor falsification or telemetry frame tampering.",
                evidence=evidence
            )

        # Rule 5: GPS Lock Degradation / Jamming Precursor
        sats = features.get("satellites_visible", 14)
        fix_type = features.get("gps_fix_type", 3)
        if sats < self.config.MIN_SATELLITES_HEALTHY or fix_type < 3:
            evidence = [
                f"Visible satellite constellation count dropped to {int(sats)} (nominal >= {self.config.MIN_SATELLITES_HEALTHY})",
                f"GPS fix downgraded to {int(fix_type)}D fix"
            ]
            return RuleCheckResult(
                is_violation=True,
                rule_id="RULE-GPS-02",
                category="gps_quality_anomaly",
                severity="monitoring",
                explanation="Severe constellation dilution or RF signal interference indicating GPS jamming or spoofing buildup.",
                evidence=evidence
            )

        return None
