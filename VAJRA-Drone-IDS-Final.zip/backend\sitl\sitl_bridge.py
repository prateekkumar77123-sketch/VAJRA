"""
ArduPilot SITL / MAVLink Passive Data Collector Bridge for VAJRA Drone IDS
Connects to ArduPilot SITL (or physical companion computer UART/UDP stream) via pymavlink.
Runs in a passive, non-intrusive listening thread to extract telemetry without interfering with flight control.
"""

import sys
import time
import argparse
from pathlib import Path
from pymavlink import mavutil
import requests

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from core.mavlink_parser import MAVLinkParser

def run_sitl_bridge(connection_str: str = "udpin:127.0.0.1:14550", backend_url: str = "http://localhost:8000/api/telemetry/ingest"):
    print(f"=== VAJRA Drone IDS — ArduPilot SITL Passive Collector ===")
    print(f"Connecting to MAVLink endpoint: {connection_str}")
    print(f"Forwarding to IDS backend: {backend_url}")

    try:
        master = mavutil.mavlink_connection(connection_str)
        print("Waiting for heartbeat from SITL/Flight Controller...")
        master.wait_heartbeat(timeout=10)
        print(f"Heartbeat received from System {master.target_system}, Component {master.target_component}")
    except Exception as e:
        print(f"Could not connect to SITL: {e}. (Ensure ArduPilot SITL is running, e.g., 'sim_vehicle.py -v ArduCopter')")
        return

    parser = MAVLinkParser(system_id=master.target_system)
    last_send = time.time()

    while True:
        try:
            msg = master.recv_match(blocking=True, timeout=1.0)
            if not msg:
                continue

            packet = parser.parse_mavlink_msg(msg)
            now = time.time()
            if packet and (now - last_send >= 0.2): # 5 Hz forwarding
                last_send = now
                try:
                    resp = requests.post(backend_url, json=packet.dict(), timeout=0.5)
                    if resp.status_code == 200:
                        res = resp.json()
                        if res.get("is_anomaly"):
                            print(f"[!] INTRUSION DETECTED: {res.get('category')} (Sev: {res.get('severity')})")
                except Exception:
                    pass
        except KeyboardInterrupt:
            print("\nShutting down SITL bridge...")
            break
        except Exception as e:
            time.sleep(0.1)

if __name__ == "__main__":
    parser_arg = argparse.ArgumentParser(description="VAJRA MAVLink SITL Bridge")
    parser_arg.add_argument("--connect", default="udpin:127.0.0.1:14550", help="MAVLink connection URI")
    parser_arg.add_argument("--backend", default="http://localhost:8000/api/telemetry/ingest", help="IDS Backend ingestion URL")
    args = parser_arg.parse_args()

    run_sitl_bridge(args.connect, args.backend)
