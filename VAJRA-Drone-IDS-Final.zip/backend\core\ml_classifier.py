"""
Stage 2 Supervised Attack Classifier for VAJRA Drone IDS
Implements Random Forest classifier for precise multi-class cyber threat classification.
"""

from pathlib import Path
import numpy as np
import joblib
from typing import Tuple, Dict, Any, Optional

class AttackClassifier:
    def __init__(self, model_path: Optional[Path] = None, scaler_path: Optional[Path] = None):
        self.model_path = model_path
        self.scaler_path = scaler_path
        self.model = None
        self.scaler = None
        self.classes_ = []
        if model_path and model_path.exists() and scaler_path and scaler_path.exists():
            self.load(model_path, scaler_path)

    def load(self, model_path: Path, scaler_path: Path):
        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)
        self.classes_ = list(self.model.classes_)

    def is_loaded(self) -> bool:
        return self.model is not None and self.scaler is not None

    def classify(self, feature_vector: np.ndarray) -> Tuple[str, float, Dict[str, float]]:
        """
        Classifies anomalous feature vector into specific attack category.
        Returns: (predicted_category, confidence_probability, all_class_probabilities)
        """
        if not self.is_loaded():
            return "unknown", 0.5, {}

        scaled_vec = self.scaler.transform(feature_vector)
        pred_idx = self.model.predict(scaled_vec)[0]
        probs = self.model.predict_proba(scaled_vec)[0]

        class_prob_map = {cls: float(prob) for cls, prob in zip(self.classes_, probs)}
        predicted_cat = str(pred_idx)
        confidence = float(np.max(probs))

        return predicted_cat, confidence, class_prob_map
