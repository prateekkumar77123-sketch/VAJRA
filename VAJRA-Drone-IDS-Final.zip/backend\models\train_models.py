"""
Model Training & Evaluation Script for VAJRA Drone IDS
Trains Stage 1 Isolation Forest and Stage 2 Random Forest Classifier,
evaluates on test dataset, computes evaluation criteria metrics (Accuracy, FPR, Recall, F1),
and serializes artifacts.
"""

import sys
import json
from pathlib import Path
import pandas as pd
import numpy as np
import joblib

from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

# Add parent directory to path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from core.feature_extractor import FeatureExtractor, FEATURE_NAMES

def prepare_feature_dataset(df: pd.DataFrame) -> pd.DataFrame:
    extractor = FeatureExtractor()
    feature_rows = []
    
    for _, row in df.iterrows():
        packet = row.to_dict()
        feats = extractor.extract_features(packet)
        feature_rows.append(feats)
        
    feat_df = pd.DataFrame(feature_rows)
    return feat_df

def train_and_evaluate():
    data_dir = BASE_DIR / "data"
    models_dir = BASE_DIR / "models" / "saved"
    models_dir.mkdir(parents=True, exist_ok=True)

    print("=== Step 1: Loading Datasets ===")
    train_path = data_dir / "train_dataset.csv"
    test_path = data_dir / "test_dataset.csv"
    train_df = pd.read_csv(train_path)
    test_df = pd.read_csv(test_path)

    print(f"Loaded {len(train_df)} training samples, {len(test_df)} test samples.")

    print("=== Step 2: Extracting Dynamic Features ===")
    X_train_df = prepare_feature_dataset(train_df)
    X_test_df = prepare_feature_dataset(test_df)

    X_train = X_train_df[FEATURE_NAMES].values
    X_test = X_test_df[FEATURE_NAMES].values
    
    y_train_binary = (train_df["label"] == "anomaly").astype(int).values
    y_test_binary = (test_df["label"] == "anomaly").astype(int).values
    
    y_train_multi = train_df["attack_type"].values
    y_test_multi = test_df["attack_type"].values

    print("=== Step 3: Scaling Features ===")
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    print("=== Step 4: Training Stage 1 - Isolation Forest (Normal-Flight Anomaly Detection) ===")
    # Train Isolation Forest predominantly on normal baseline flight data
    normal_mask = (train_df["attack_type"] == "none") | (train_df["attack_type"] == "normal")
    X_normal_scaled = X_train_scaled[normal_mask]
    
    iso_forest = IsolationForest(
        n_estimators=100,
        contamination=0.03,
        random_state=42,
        n_jobs=-1
    )
    iso_forest.fit(X_normal_scaled)

    # Evaluate Stage 1 on test set
    raw_scores = iso_forest.decision_function(X_test_scaled)
    stage1_pred_binary = (0.5 - raw_scores >= 0.55).astype(int)

    s1_acc = accuracy_score(y_test_binary, stage1_pred_binary)
    tn, fp, fn, tp = confusion_matrix(y_test_binary, stage1_pred_binary).ravel()
    s1_fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

    print(f"Stage 1 Anomaly Detection Accuracy: {s1_acc*100:.2f}%")
    print(f"Stage 1 False Positive Rate (FPR): {s1_fpr*100:.2f}% (FP={fp}, TN={tn})")

    print("=== Step 5: Training Stage 2 - Multi-Class Attack Classifier ===")
    clf = RandomForestClassifier(
        n_estimators=120,
        max_depth=14,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1
    )
    clf.fit(X_train_scaled, y_train_multi)

    y_test_pred = clf.predict(X_test_scaled)
    s2_acc = accuracy_score(y_test_multi, y_test_pred)
    s2_prec = precision_score(y_test_multi, y_test_pred, average="weighted", zero_division=0)
    s2_rec = recall_score(y_test_multi, y_test_pred, average="weighted", zero_division=0)
    s2_f1 = f1_score(y_test_multi, y_test_pred, average="weighted", zero_division=0)

    print(f"Stage 2 Attack Classifier Accuracy: {s2_acc*100:.2f}%")
    print(f"Stage 2 Weighted Precision: {s2_prec*100:.2f}%")
    print(f"Stage 2 Weighted Recall: {s2_rec*100:.2f}%")
    print(f"Stage 2 Weighted F1 Score: {s2_f1*100:.2f}%")

    print("\n--- Detailed Classification Report ---")
    print(classification_report(y_test_multi, y_test_pred, zero_division=0))

    print("=== Step 6: Serializing Model Artifacts ===")
    joblib.dump(scaler, models_dir / "scaler.joblib")
    joblib.dump(iso_forest, models_dir / "isolation_forest.joblib")
    joblib.dump(clf, models_dir / "attack_classifier.joblib")

    metadata = {
        "model_version": "2.0.0",
        "trained_date": "2026-09-26",
        "features": FEATURE_NAMES,
        "classes": list(clf.classes_),
        "metrics": {
            "overall_accuracy": float(s2_acc),
            "false_positive_rate": float(s1_fpr),
            "precision": float(s2_prec),
            "recall": float(s2_rec),
            "f1_score": float(s2_f1),
            "stage1_accuracy": float(s1_acc)
        }
    }
    with open(models_dir / "model_metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print(f"Artifacts successfully saved to: {models_dir}")
    return metadata

if __name__ == "__main__":
    train_and_evaluate()
