"""
Unit & Integrity Tests for VAJRA Drone IDS Blockchain Algorithm
Tests Merkle Tree computation, Proof-of-Work, chain verification, and tamper detection.
"""

import sys
import unittest
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from core.blockchain import BlockchainLedger, MerkleTree

class TestBlockchainLedger(unittest.TestCase):
    def setUp(self):
        self.test_ledger_path = BASE_DIR / "data" / "unit_test_ledger.json"
        if self.test_ledger_path.exists():
            self.test_ledger_path.unlink()
        self.ledger = BlockchainLedger(difficulty=2, ledger_path=self.test_ledger_path)

    def tearDown(self):
        if self.test_ledger_path.exists():
            self.test_ledger_path.unlink()

    def test_genesis_block(self):
        """Genesis block must exist, have index 0, and meet PoW target."""
        self.assertEqual(len(self.ledger.chain), 1)
        genesis = self.ledger.chain[0]
        self.assertEqual(genesis.index, 0)
        self.assertEqual(genesis.previous_hash, "0" * 64)
        self.assertTrue(genesis.hash.startswith("00"))

    def test_merkle_tree_consistency(self):
        """Merkle root must be deterministic and sensitive to single-byte changes."""
        leaves1 = ["tx_001_gps_spoofing", "tx_002_dos_attack", "tx_003_cmd_inject"]
        root1 = MerkleTree.compute_root(leaves1)
        root2 = MerkleTree.compute_root(leaves1)
        self.assertEqual(root1, root2, "Merkle root must be identical for identical leaves")

        # Mutate one byte
        leaves_mutated = ["tx_001_gps_spoofing", "tx_002_dos_attack_MUTATED", "tx_003_cmd_inject"]
        root_mutated = MerkleTree.compute_root(leaves_mutated)
        self.assertNotEqual(root1, root_mutated, "Merkle root must change upon data modification")

    def test_add_evidence_and_mine(self):
        """Adding evidence should mine a new block with valid previous_hash link."""
        rec = {
            "event_id": "evt_test_01",
            "category": "gps_spoofing",
            "severity": "critical",
            "evidence": ["GPS jumped 340m"]
        }
        res = self.ledger.add_evidence_record(rec, auto_mine=True)
        self.assertEqual(res["status"], "anchored")
        self.assertEqual(len(self.ledger.chain), 2)
        
        block1 = self.ledger.chain[1]
        self.assertEqual(block1.index, 1)
        self.assertEqual(block1.previous_hash, self.ledger.chain[0].hash)
        self.assertTrue(block1.hash.startswith("00"))

    def test_chain_validation_and_tamper_detection(self):
        """Valid chain passes; tampered data fails validation immediately."""
        # 1. Add 3 blocks
        for i in range(3):
            self.ledger.add_evidence_record({"test_id": i, "data": f"payload_{i}"}, auto_mine=True)

        val_result = self.ledger.validate_chain()
        self.assertTrue(val_result["valid"], "Untampered chain must be completely valid")

        # 2. Simulate malicious tamper on block #1
        tamper_res = self.ledger.simulate_tamper(block_index=1, key="data", new_value="MALICIOUS_FORGERY")
        self.assertEqual(tamper_res["status"], "tampered")

        # 3. Validate chain after tamper
        tampered_val = self.ledger.validate_chain()
        self.assertFalse(tampered_val["valid"], "Tampered chain must be caught as INVALID")
        self.assertIn(tampered_val["error_type"], ["MERKLE_ROOT_TAMPERED", "HASH_CORRUPTION"])
        self.assertEqual(tampered_val["block_index"], 1)

if __name__ == "__main__":
    unittest.main()
