"""
Feature Extractor for VAJRA Drone IDS
Calculates temporal, kinematic, communication, and physical consistency features
over configurable sliding time windows.
"""

import math
from typing import List, Dict, Any, Optional
from collections import deque
import numpy as np

FEATURE_NAMES = [
    "ground_speed_mps",
    "altitude_m",
    "vertical_speed_mps",
    "gps_displacement_m",
    "speed_vs_displacement_diff",
    "roll_rad",
    "pitch_rad",
    "yaw_rad",
    "angular_rate_magnitude",
    "satellites_visible",
    "gps_fix_type",
    "battery_voltage_v",
    "battery_voltage_drop_rate",
    "battery_current_a",
    "mavlink_message_rate_hz",
    "message_rate_delta",
    "packet_loss_percent",
    "command_rate_hz",
    "command_rate_spike"
]

class FeatureExtractor:
    def __init__(self, window_size: int = 5):
        self.window_size = window_size
        self.buffer = deque(maxlen=window_size)
        self.total_distance_m = 0.0
        self.last_valid_lat = None
        self.last_valid_lon = None

    @staticmethod
    def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Computes great circle distance between two points in meters."""
        R = 6371000.0  # Earth radius in meters
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)

        a = math.sin(delta_phi / 2.0)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2.0)**2
        c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
        return R * c

    def update_distance(self, lat: float, lon: float) -> float:
        if self.last_valid_lat is not None and self.last_valid_lon is not None:
            d = self.haversine_distance(self.last_valid_lat, self.last_valid_lon, lat, lon)
            # Only accumulate realistic flight distance (ignore >100m/s teleport jumps)
            if d < 100.0:
                self.total_distance_m += d
        self.last_valid_lat = lat
        self.last_valid_lon = lon
        return self.total_distance_m

    def extract_features(self, packet_dict: Dict[str, Any]) -> Dict[str, float]:
        """
        Ingests a new telemetry packet and extracts real-time feature vector.
        """
        self.buffer.append(packet_dict)
        self.update_distance(packet_dict["latitude_deg"], packet_dict["longitude_deg"])

        dt = 1.0  # nominal 1 second step
        if len(self.buffer) >= 2:
            prev = self.buffer[-2]
            curr = self.buffer[-1]
            time_diff = (curr.get("timestamp_ms", 1000) - prev.get("timestamp_ms", 0)) / 1000.0
            if time_diff > 0.05:
                dt = time_diff

            # Kinematic & Displacement features
            disp_m = self.haversine_distance(
                prev["latitude_deg"], prev["longitude_deg"],
                curr["latitude_deg"], curr["longitude_deg"]
            )
            v_speed = (curr["altitude_m"] - prev["altitude_m"]) / dt
            derived_speed = disp_m / dt
            speed_diff = abs(curr["ground_speed_mps"] - derived_speed)

            # Battery drop rate
            prev_v = prev.get("battery_voltage_v", 16.5)
            curr_v = curr.get("battery_voltage_v", 16.5)
            batt_drop_rate = (prev_v - curr_v) / dt
            
            # Communication & command deltas
            rate_delta = abs(curr.get("mavlink_message_rate_hz", 48.0) - prev.get("mavlink_message_rate_hz", 48.0))
            cmd_spike = max(0.0, curr.get("command_rate_hz", 0.2) - prev.get("command_rate_hz", 0.2))
        else:
            disp_m = 0.0
            v_speed = 0.0
            speed_diff = 0.0
            batt_drop_rate = 0.0
            rate_delta = 0.0
            cmd_spike = 0.0

        curr = packet_dict
        # Angular rates magnitude
        roll_spd = curr.get("rollspeed_rad_s", 0.0)
        pitch_spd = curr.get("pitchspeed_rad_s", 0.0)
        yaw_spd = curr.get("yawspeed_rad_s", 0.0)
        ang_mag = math.sqrt(roll_spd**2 + pitch_spd**2 + yaw_spd**2)

        features = {
            "ground_speed_mps": float(curr["ground_speed_mps"]),
            "altitude_m": float(curr["altitude_m"]),
            "vertical_speed_mps": float(v_speed),
            "gps_displacement_m": float(disp_m),
            "speed_vs_displacement_diff": float(speed_diff),
            "roll_rad": float(curr.get("roll_rad", 0.0)),
            "pitch_rad": float(curr.get("pitch_rad", 0.0)),
            "yaw_rad": float(curr.get("yaw_rad", 0.0)),
            "angular_rate_magnitude": float(ang_mag),
            "satellites_visible": float(curr.get("satellites_visible", 14)),
            "gps_fix_type": float(curr.get("gps_fix_type", 3)),
            "battery_voltage_v": float(curr.get("battery_voltage_v", 16.5)),
            "battery_voltage_drop_rate": float(batt_drop_rate),
            "battery_current_a": float(curr.get("battery_current_a", 4.5)),
            "mavlink_message_rate_hz": float(curr.get("mavlink_message_rate_hz", 48.0)),
            "message_rate_delta": float(rate_delta),
            "packet_loss_percent": float(curr.get("packet_loss_percent", 1.0)),
            "command_rate_hz": float(curr.get("command_rate_hz", 0.2)),
            "command_rate_spike": float(cmd_spike)
        }
        return features

    def to_feature_vector(self, features: Dict[str, float]) -> np.ndarray:
        """Converts feature dict to ordered numpy array for ML inference."""
        return np.array([features[name] for name in FEATURE_NAMES], dtype=np.float32).reshape(1, -1)
