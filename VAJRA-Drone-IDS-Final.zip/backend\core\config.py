"""
VAJRA Drone IDS Configuration
System-wide settings, flight envelopes, physical thresholds, and blockchain parameters.
"""

from pydantic import BaseModel
from typing import Dict, Any

class IDSConfig(BaseModel):
    # System settings
    APP_NAME: str = "VAJRA Drone IDS"
    VERSION: str = "2.0.0"
    AIRFRAME_TYPE: str = "Quadcopter / Multi-Rotor UAV"
    TARGET_HARDWARE: str = "Raspberry Pi 5 / Companion Computer"
    
    # Feature windowing
    WINDOW_SIZE: int = 5          # Number of telemetry steps in sliding window
    TELEMETRY_FREQ_HZ: float = 1.0  # Processing frequency
    
    # Flight Envelope Thresholds (Physical sanity bounds)
    MAX_HORIZONTAL_ACCEL_MPS2: float = 12.0     # Max plausible drone acceleration
    MAX_GROUND_SPEED_MPS: float = 25.0          # Max speed in m/s (~90 km/h)
    MAX_VERTICAL_SPEED_MPS: float = 8.0         # Max climb/sink rate
    MAX_GPS_JUMP_METERS_PER_SEC: float = 20.0   # Beyond this without high accel = spoofing
    MIN_SATELLITES_HEALTHY: int = 8             # Below this with 2D fix = quality alert
    MAX_VOLTAGE_DROP_RATE_VPS: float = 0.5      # Max normal battery drop in V/sec
    
    # Communication Limits
    MAX_MAVLINK_RATE_HZ: float = 120.0          # Normal MAVLink rate is 30-60 Hz
    MAX_PACKET_LOSS_PERCENT: float = 15.0       # Normal loss < 3%
    MAX_COMMAND_RATE_HZ: float = 2.0            # Normal command rate < 0.5 Hz
    
    # Two-Stage ML Decision Thresholds
    STAGE1_ANOMALY_THRESHOLD: float = 0.65      # Isolation forest anomaly score threshold
    STAGE2_CONF_THRESHOLD: float = 0.70         # Random Forest classification confidence
    
    # Blockchain Settings
    BLOCKCHAIN_DIFFICULTY: int = 2              # Proof of Work difficulty (zeros prefix) for PoC
    BLOCKCHAIN_BATCH_SIZE: int = 10             # Evidence items per mined block
    BLOCKCHAIN_NETWORK: str = "VAJRA-Consortium-Ledger"

CONFIG = IDSConfig()
