"""
MAVLink Parser and Telemetry Normalizer for VAJRA Drone IDS
Processes incoming MAVLink 2.0 messages (or simulated feeds) into standardized telemetry frames.
"""

import time
import math
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field

class TelemetryPacket(BaseModel):
    timestamp_ms: int
    system_id: int = 1
    component_id: int = 1
    latitude_deg: float
    longitude_deg: float
    altitude_m: float
    relative_altitude_m: float
    ground_speed_mps: float
    heading_deg: float
    roll_rad: float = 0.0
    pitch_rad: float = 0.0
    yaw_rad: float = 0.0
    rollspeed_rad_s: float = 0.0
    pitchspeed_rad_s: float = 0.0
    yawspeed_rad_s: float = 0.0
    gps_fix_type: int = 3
    satellites_visible: int = 14
    battery_voltage_v: float = 16.5
    battery_current_a: float = 4.5
    mavlink_message_rate_hz: float = 48.0
    packet_loss_percent: float = 1.0
    command_rate_hz: float = 0.2
    flight_mode: str = "AUTO"
    rssi_dbm: float = -55.0

class MAVLinkParser:
    """
    Parses native pymavlink message objects into normalized TelemetryPacket frames.
    """
    def __init__(self, system_id: int = 1):
        self.target_system_id = system_id
        self._current_state = {
            "timestamp_ms": int(time.time() * 1000),
            "system_id": system_id,
            "component_id": 1,
            "latitude_deg": 28.6139,
            "longitude_deg": 77.2090,
            "altitude_m": 20.0,
            "relative_altitude_m": 0.0,
            "ground_speed_mps": 5.0,
            "heading_deg": 90.0,
            "roll_rad": 0.0,
            "pitch_rad": 0.0,
            "yaw_rad": 1.57,
            "rollspeed_rad_s": 0.0,
            "pitchspeed_rad_s": 0.0,
            "yawspeed_rad_s": 0.0,
            "gps_fix_type": 3,
            "satellites_visible": 14,
            "battery_voltage_v": 16.6,
            "battery_current_a": 4.5,
            "mavlink_message_rate_hz": 48.0,
            "packet_loss_percent": 1.0,
            "command_rate_hz": 0.2,
            "flight_mode": "AUTO",
            "rssi_dbm": -55.0
        }
        self.msg_count = 0
        self.last_rate_calc = time.time()
        self.command_count = 0

    def parse_mavlink_msg(self, msg) -> Optional[TelemetryPacket]:
        """
        Takes a pymavlink message instance and updates internal state.
        Returns a TelemetryPacket when complete navigation/attitude state is ready.
        """
        if msg is None:
            return None

        msg_type = msg.get_type()
        self.msg_count += 1
        now = time.time()
        if now - self.last_rate_calc >= 1.0:
            self._current_state["mavlink_message_rate_hz"] = self.msg_count / (now - self.last_rate_calc)
            self._current_state["command_rate_hz"] = self.command_count / (now - self.last_rate_calc)
            self.msg_count = 0
            self.command_count = 0
            self.last_rate_calc = now

        if msg_type == "GLOBAL_POSITION_INT":
            self._current_state["latitude_deg"] = msg.lat / 1e7
            self._current_state["longitude_deg"] = msg.lon / 1e7
            self._current_state["altitude_m"] = msg.alt / 1000.0
            self._current_state["relative_altitude_m"] = msg.relative_alt / 1000.0
            vx = msg.vx / 100.0
            vy = msg.vy / 100.0
            self._current_state["ground_speed_mps"] = math.sqrt(vx**2 + vy**2)
            self._current_state["heading_deg"] = msg.hdg / 100.0
            self._current_state["timestamp_ms"] = int(time.time() * 1000)

        elif msg_type == "GPS_RAW_INT":
            self._current_state["gps_fix_type"] = msg.fix_type
            self._current_state["satellites_visible"] = msg.satellites_visible

        elif msg_type == "ATTITUDE":
            self._current_state["roll_rad"] = msg.roll
            self._current_state["pitch_rad"] = msg.pitch
            self._current_state["yaw_rad"] = msg.yaw
            self._current_state["rollspeed_rad_s"] = msg.rollspeed
            self._current_state["pitchspeed_rad_s"] = msg.pitchspeed
            self._current_state["yawspeed_rad_s"] = msg.yawspeed

        elif msg_type == "SYS_STATUS":
            self._current_state["battery_voltage_v"] = msg.voltage_battery / 1000.0
            self._current_state["battery_current_a"] = msg.current_battery / 100.0
            self._current_state["packet_loss_percent"] = msg.drop_rate_comm / 100.0

        elif msg_type in ["COMMAND_LONG", "COMMAND_INT"]:
            self.command_count += 1

        return TelemetryPacket(**self._current_state)

    def parse_dict(self, data: Dict[str, Any]) -> TelemetryPacket:
        """Parses a normalized dictionary into a TelemetryPacket."""
        return TelemetryPacket(**data)
