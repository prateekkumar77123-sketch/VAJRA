"""
Benchmark & Performance Verification Script for VAJRA Drone IDS
Measures evaluation criteria specified in PUSHPAK Grand Challenge 2026 Objective 2:
1. Detection accuracy across attack scenarios (20%)
2. False Positive Rate (FPR) (20%)
3. Distance Covered (10%)
4. Detection latency (10%)
5. Coverage of multiple attack vectors (15%)
6. Computational efficiency (10%)
"""

import sys
import time
import json
from pathlib import Path
import pandas as pd
import numpy as np

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from core.ids_pipeline import IDSPipeline

def run_benchmarks():
    data_dir = BASE_DIR / "data"
    models_dir = BASE_DIR / "models" / "saved"
    ledger_path = BASE_DIR / "data" / "benchmark_ledger.json"
    if ledger_path.exists():
        ledger_path.unlink()

    print("======================================================================")
    print("      VAJRA DRONE IDS — OBJECTIVE 2 BENCHMARK & EVALUATION SUITE      ")
    print("======================================================================")

    test_path = data_dir / "test_dataset.csv"
    test_df = pd.read_csv(test_path)
    print(f"Loaded unseen evaluation dataset: {len(test_df)} telemetry packets.")

    pipeline = IDSPipeline(models_dir=models_dir, ledger_path=ledger_path)

    latencies_ms = []
    y_true_binary = []
    y_pred_binary = []
    y_true_category = []
    y_pred_category = []

    print("\nExecuting real-time inference loop...")
    for idx, row in test_df.iterrows():
        packet = row.to_dict()
        t0 = time.perf_counter()
        res = pipeline.process_packet(packet)
        elapsed_ms = (time.perf_counter() - t0) * 1000.0
        latencies_ms.append(elapsed_ms)

        true_anomaly = 1 if row["label"] == "anomaly" else 0
        pred_anomaly = 1 if res["is_anomaly"] else 0
        y_true_binary.append(true_anomaly)
        y_pred_binary.append(pred_anomaly)

        true_cat = row["attack_type"]
        pred_cat = res["category"]
        y_true_category.append(true_cat)
        y_pred_category.append(pred_cat)

    # 1. Detection Accuracy
    correct_binary = sum(yt == yp for yt, yp in zip(y_true_binary, y_pred_binary))
    binary_acc = correct_binary / len(y_true_binary)

    # 2. False Positive Rate (FPR)
    # FP = true is 0, predicted is 1. TN = true is 0, predicted is 0.
    fp = sum(yt == 0 and yp == 1 for yt, yp in zip(y_true_binary, y_pred_binary))
    tn = sum(yt == 0 and yp == 0 for yt, yp in zip(y_true_binary, y_pred_binary))
    tp = sum(yt == 1 and yp == 1 for yt, yp in zip(y_true_binary, y_pred_binary))
    fn = sum(yt == 1 and yp == 0 for yt, yp in zip(y_true_binary, y_pred_binary))
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0

    # 3. Distance Covered
    total_dist_m = pipeline.feature_extractor.total_distance_m

    # 4. Latency
    avg_latency = float(np.mean(latencies_ms))
    p95_latency = float(np.percentile(latencies_ms, 95))
    max_latency = float(np.max(latencies_ms))
    throughput_pps = 1000.0 / avg_latency if avg_latency > 0 else 0.0

    # 5. Attack Vector Coverage
    unique_vectors = sorted(list(set(test_df["attack_type"]) - {"none", "normal"}))

    # 6. Blockchain verification
    bc_valid = pipeline.blockchain.validate_chain()

    print("\n----------------------------------------------------------------------")
    print("                      OFFICIAL BENCHMARK RESULTS                      ")
    print("----------------------------------------------------------------------")
    print(f" Total Telemetry Frames Tested   : {len(test_df)}")
    print(f" Detection Accuracy              : {binary_acc * 100.0:.2f}% (Target: >95%)")
    print(f" False Positive Rate (FPR)       : {fpr * 100.0:.2f}% (Target: <5.0%, Evaluation Weight: 20%)")
    print(f" Precision                       : {precision * 100.0:.2f}%")
    print(f" Recall / Sensitivity            : {recall * 100.0:.2f}%")
    print(f" F1-Score                        : {f1 * 100.0:.2f}%")
    print(f" Distance Covered                : {total_dist_m:.2f} m ({total_dist_m/1000.0:.3f} km)")
    print(f" Average Detection Latency       : {avg_latency:.3f} ms (Target: <10 ms, Weight: 10%)")
    print(f" 95th Percentile Latency         : {p95_latency:.3f} ms")
    print(f" Maximum Latency                 : {max_latency:.3f} ms")
    print(f" Processing Throughput           : {throughput_pps:.0f} packets/second")
    print(f" Attack Vectors Evaluated ({len(unique_vectors)}) : {', '.join(unique_vectors)}")
    print(f" Blockchain Ledger Status        : {bc_valid['total_blocks']} blocks verified (Chain Valid: {bc_valid['valid']})")
    print("======================================================================\n")

    benchmark_summary = {
        "detection_accuracy_pct": round(binary_acc * 100.0, 2),
        "false_positive_rate_pct": round(fpr * 100.0, 2),
        "precision_pct": round(precision * 100.0, 2),
        "recall_pct": round(recall * 100.0, 2),
        "f1_score_pct": round(f1 * 100.0, 2),
        "distance_covered_m": round(total_dist_m, 2),
        "average_latency_ms": round(avg_latency, 3),
        "p95_latency_ms": round(p95_latency, 3),
        "throughput_pps": round(throughput_pps, 1),
        "attack_vectors_covered": unique_vectors,
        "blockchain_valid": bc_valid["valid"],
        "total_blockchain_blocks": bc_valid["total_blocks"]
    }

    report_path = BASE_DIR.parent / "docs" / "BENCHMARK_RESULTS.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(benchmark_summary, f, indent=2)

    return benchmark_summary

if __name__ == "__main__":
    run_benchmarks()
