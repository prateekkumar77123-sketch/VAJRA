"""
Dataset Generator for VAJRA Drone IDS
Generates realistic multi-scenario MAVLink telemetry for normal flights and attack vectors.
Vectors:
1. Normal Flight (waypoint navigation, loiter, manual cruise)
2. GPS Spoofing (sudden coordinate offsets, trajectory jump, velocity disagreement)
3. MAVLink DoS / Flooding (packet flood >180Hz, packet loss 20-40%)
4. Command Injection (unauthorized MAV_CMD flood, unexpected flight mode change)
5. Telemetry Manipulation (impossible altitude/speed changes, battery voltage paradox)
6. GPS Quality / Jamming (satellite drop, fix degradation, HDOP spike)
7. Firmware / Param Tampering (unauthorized param modifications)
"""

import math
import random
import numpy as np
import pandas as pd
from pathlib import Path

def generate_telemetry_dataset(output_dir: Path, n_episodes: int = 15, samples_per_episode: int = 160):
    output_dir.mkdir(parents=True, exist_ok=True)
    random.seed(42)
    np.random.seed(42)
    
    rows = []
    current_time_ms = 100000

    base_lat = 28.6139
    base_lon = 77.2090

    attack_types = [
        "normal",
        "gps_spoofing",
        "mavlink_dos",
        "command_injection",
        "telemetry_manipulation",
        "gps_quality_anomaly",
        "firmware_param_tamper"
    ]

    for ep in range(n_episodes):
        # Choose scenario for episode
        if ep % 4 == 0:
            scenario = "normal"
        else:
            scenario = attack_types[1 + ((ep - 1) % (len(attack_types) - 1))]

        # Initial conditions for this flight episode
        lat = base_lat + random.uniform(-0.005, 0.005)
        lon = base_lon + random.uniform(-0.005, 0.005)
        alt = random.uniform(18.0, 35.0)
        rel_alt = alt - 20.0
        spd = random.uniform(4.5, 7.5)
        hdg = random.uniform(0.0, 360.0)
        roll = random.uniform(-0.03, 0.03)
        pitch = random.uniform(-0.03, 0.03)
        yaw = math.radians(hdg)
        batt_v = random.uniform(16.2, 16.8)
        batt_a = random.uniform(4.0, 5.5)
        msg_rate = random.uniform(44.0, 52.0)
        pkt_loss = random.uniform(0.2, 2.0)
        cmd_rate = random.uniform(0.1, 0.4)
        sats = random.randint(13, 17)
        gps_fix = 3

        # Attack window inside episode (e.g. from step 60 to 100)
        attack_start = 60
        attack_end = 105

        for step in range(samples_per_episode):
            current_time_ms += 1000
            is_attack = (scenario != "normal") and (attack_start <= step < attack_end)
            curr_attack = scenario if is_attack else "none"
            curr_label = "anomaly" if is_attack else "normal"

            # Physics updates (Nominal kinematic simulation)
            hdg_rad = math.radians(hdg)
            d_lat = (spd * math.cos(hdg_rad)) / 111320.0
            d_lon = (spd * math.sin(hdg_rad)) / (111320.0 * math.cos(math.radians(lat)))
            lat += d_lat + np.random.normal(0, 0.000005)
            lon += d_lon + np.random.normal(0, 0.000005)
            alt += np.random.normal(0, 0.15)
            rel_alt = alt - 20.0
            spd = max(1.0, spd + np.random.normal(0, 0.1))
            hdg = (hdg + np.random.normal(0.8, 1.2)) % 360.0
            roll = np.random.normal(0, 0.02)
            pitch = np.random.normal(0, 0.02)
            yaw = math.radians(hdg)
            roll_spd = np.random.normal(0, 0.008)
            pitch_spd = np.random.normal(0, 0.008)
            yaw_spd = np.random.normal(0.02, 0.008)
            batt_v = max(14.0, batt_v - 0.0005)
            batt_a = max(2.0, batt_a + np.random.normal(0, 0.1))
            msg_rate = max(10.0, msg_rate + np.random.normal(0, 1.5))
            pkt_loss = max(0.0, min(100.0, pkt_loss + np.random.normal(0, 0.2)))
            cmd_rate = max(0.05, cmd_rate + np.random.normal(0, 0.05))
            sats = random.randint(13, 17)
            gps_fix = 3

            # Apply attacks when active
            out_lat, out_lon, out_alt = lat, lon, alt
            out_spd, out_msg_rate, out_pkt_loss = spd, msg_rate, pkt_loss
            out_cmd_rate, out_sats, out_gps_fix = cmd_rate, sats, gps_fix
            out_batt_v = batt_v

            if is_attack:
                if scenario == "gps_spoofing":
                    # Instant coordinate teleportation without kinematic acceleration
                    out_lat += random.uniform(0.0018, 0.0035)
                    out_lon += random.uniform(0.0020, 0.0040)
                    out_spd = random.uniform(9.0, 16.0)
                elif scenario == "mavlink_dos":
                    # Flood of packets + heavy dropped packets
                    out_msg_rate = random.uniform(170.0, 240.0)
                    out_pkt_loss = random.uniform(22.0, 42.0)
                elif scenario == "command_injection":
                    # Spurious command frequency flood
                    out_cmd_rate = random.uniform(5.5, 12.0)
                elif scenario == "telemetry_manipulation":
                    # Unphysical sensor contradictions (e.g. altitude jumps 40m, speed reported 0.1m/s)
                    out_alt += random.uniform(35.0, 50.0)
                    out_spd = 0.2
                    out_batt_v += 1.5 # impossible battery surge
                elif scenario == "gps_quality_anomaly":
                    # Jamming / spoofing precursor: lock degradation
                    out_sats = random.randint(2, 4)
                    out_gps_fix = random.choice([1, 2])
                elif scenario == "firmware_param_tamper":
                    # Param corruption: sudden abnormal packet loss + message timing anomaly
                    out_pkt_loss = random.uniform(15.0, 28.0)
                    out_cmd_rate = random.uniform(2.5, 5.0)

            rows.append({
                "timestamp_ms": current_time_ms,
                "system_id": 1,
                "component_id": 1,
                "latitude_deg": out_lat,
                "longitude_deg": out_lon,
                "altitude_m": out_alt,
                "relative_altitude_m": out_alt - 20.0,
                "ground_speed_mps": out_spd,
                "heading_deg": hdg,
                "roll_rad": roll,
                "pitch_rad": pitch,
                "yaw_rad": yaw,
                "rollspeed_rad_s": roll_spd,
                "pitchspeed_rad_s": pitch_spd,
                "yawspeed_rad_s": yaw_spd,
                "gps_fix_type": out_gps_fix,
                "satellites_visible": out_sats,
                "battery_voltage_v": out_batt_v,
                "battery_current_a": batt_a,
                "mavlink_message_rate_hz": out_msg_rate,
                "packet_loss_percent": out_pkt_loss,
                "command_rate_hz": out_cmd_rate,
                "label": curr_label,
                "attack_type": curr_attack
            })

    df = pd.DataFrame(rows)
    
    # Split by flight episodes (75% train, 25% test) to prevent temporal leakage
    episode_ids = np.repeat(range(n_episodes), samples_per_episode)
    df["episode"] = episode_ids
    train_eps = [i for i in range(n_episodes) if i % 4 != 3]
    test_eps = [i for i in range(n_episodes) if i % 4 == 3]

    train_df = df[df["episode"].isin(train_eps)].drop(columns=["episode"])
    test_df = df[df["episode"].isin(test_eps)].drop(columns=["episode"])
    
    # Prepend original provided dataset to training data for authentic calibration
    orig_path = output_dir / "mavlink_raw.csv"
    if orig_path.exists():
        orig_df = pd.read_csv(orig_path)
        train_df = pd.concat([orig_df, train_df], ignore_index=True)

    train_path = output_dir / "train_dataset.csv"
    test_path = output_dir / "test_dataset.csv"
    train_df.to_csv(train_path, index=False)
    test_df.to_csv(test_path, index=False)

    print(f"Generated train dataset: {train_path} ({len(train_df)} samples)")
    print(f"Generated test dataset: {test_path} ({len(test_df)} samples)")
    print("Class distribution in test set:\n", test_df["attack_type"].value_counts())
    return train_path, test_path

if __name__ == "__main__":
    data_dir = Path(__file__).resolve().parent
    generate_telemetry_dataset(data_dir, n_episodes=16, samples_per_episode=150)
