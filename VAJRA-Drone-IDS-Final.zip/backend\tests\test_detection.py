"""
Unit & Integration Validation Suite for VAJRA Drone IDS
Tests representative attack test cases TC-01 to TC-06 according to PUSHPAK Objective 2 rules.
"""

import sys
import unittest
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from core.config import CONFIG
from core.ids_pipeline import IDSPipeline

class TestDroneIDSDetection(unittest.TestCase):
    def setUp(self):
        models_dir = BASE_DIR / "models" / "saved"
        ledger_path = BASE_DIR / "data" / "test_ledger.json"
        if ledger_path.exists():
            try:
                ledger_path.unlink()
            except Exception:
                pass
        self.pipeline = IDSPipeline(models_dir=models_dir, ledger_path=ledger_path)

    def test_tc01_gps_spoofing(self):
        """TC-01: Injected GPS coordinate jump must trigger GPS Spoofing alert."""
        # 1st packet normal
        p1 = {
            "timestamp_ms": 100000, "latitude_deg": 28.6139, "longitude_deg": 77.2090,
            "altitude_m": 20.0, "ground_speed_mps": 5.0, "heading_deg": 90.0,
            "mavlink_message_rate_hz": 48.0, "packet_loss_percent": 1.0, "command_rate_hz": 0.2
        }
        self.pipeline.process_packet(p1)

        # 2nd packet teleported 250m away in 1 second
        p2 = {
            "timestamp_ms": 101000, "latitude_deg": 28.6165, "longitude_deg": 77.2125,
            "altitude_m": 20.2, "ground_speed_mps": 14.0, "heading_deg": 95.0,
            "mavlink_message_rate_hz": 48.0, "packet_loss_percent": 1.0, "command_rate_hz": 0.2
        }
        res = self.pipeline.process_packet(p2)
        self.assertTrue(res["is_anomaly"], "GPS jump should be flagged as anomaly")
        self.assertEqual(res["category"], "gps_spoofing", "Attack category must be gps_spoofing")
        self.assertGreaterEqual(res["confidence_score"], 6.0)

    def test_tc02_mavlink_dos(self):
        """TC-02: Message rate surge to 200 Hz with high packet loss triggers MAVLink DoS."""
        p = {
            "timestamp_ms": 102000, "latitude_deg": 28.6139, "longitude_deg": 77.2090,
            "altitude_m": 20.0, "ground_speed_mps": 5.0, "heading_deg": 90.0,
            "mavlink_message_rate_hz": 210.0, "packet_loss_percent": 32.0, "command_rate_hz": 0.2
        }
        res = self.pipeline.process_packet(p)
        self.assertTrue(res["is_anomaly"])
        self.assertEqual(res["category"], "mavlink_dos")
        self.assertEqual(res["severity"], "critical")

    def test_tc03_command_injection(self):
        """TC-03: Command rate spike to 8.5 Hz triggers Command Injection alert."""
        p = {
            "timestamp_ms": 103000, "latitude_deg": 28.6139, "longitude_deg": 77.2090,
            "altitude_m": 20.0, "ground_speed_mps": 5.0, "heading_deg": 90.0,
            "mavlink_message_rate_hz": 48.0, "packet_loss_percent": 1.0, "command_rate_hz": 8.5
        }
        res = self.pipeline.process_packet(p)
        self.assertTrue(res["is_anomaly"])
        self.assertEqual(res["category"], "command_injection")

    def test_tc04_telemetry_manipulation(self):
        """TC-04: Unphysical vertical speed and sensor conflict triggers telemetry manipulation."""
        p1 = {
            "timestamp_ms": 104000, "latitude_deg": 28.6139, "longitude_deg": 77.2090,
            "altitude_m": 20.0, "ground_speed_mps": 5.0, "heading_deg": 90.0,
            "battery_voltage_v": 16.5, "mavlink_message_rate_hz": 48.0, "packet_loss_percent": 1.0, "command_rate_hz": 0.2
        }
        self.pipeline.process_packet(p1)

        p2 = {
            "timestamp_ms": 105000, "latitude_deg": 28.6139, "longitude_deg": 77.2090,
            "altitude_m": 65.0,  # 45m climb in 1s impossible for multicopter
            "ground_speed_mps": 0.1, "heading_deg": 90.0,
            "battery_voltage_v": 18.0,  # impossible surge
            "mavlink_message_rate_hz": 48.0, "packet_loss_percent": 1.0, "command_rate_hz": 0.2
        }
        res = self.pipeline.process_packet(p2)
        self.assertTrue(res["is_anomaly"])
        self.assertEqual(res["category"], "telemetry_manipulation")

    def test_tc05_gps_quality_jamming(self):
        """TC-05: Satellite drop to 3 and fix degradation triggers GPS quality alert."""
        p = {
            "timestamp_ms": 106000, "latitude_deg": 28.6139, "longitude_deg": 77.2090,
            "altitude_m": 20.0, "ground_speed_mps": 5.0, "heading_deg": 90.0,
            "satellites_visible": 3, "gps_fix_type": 2,
            "mavlink_message_rate_hz": 48.0, "packet_loss_percent": 1.0, "command_rate_hz": 0.2
        }
        res = self.pipeline.process_packet(p)
        self.assertTrue(res["is_anomaly"])
        self.assertEqual(res["category"], "gps_quality_anomaly")

    def test_tc06_nominal_flight(self):
        """TC-06: Nominal flight telemetry must remain unflagged."""
        p = {
            "timestamp_ms": 107000, "latitude_deg": 28.61391, "longitude_deg": 77.20901,
            "altitude_m": 20.1, "ground_speed_mps": 5.2, "heading_deg": 91.0,
            "satellites_visible": 15, "gps_fix_type": 3,
            "mavlink_message_rate_hz": 48.0, "packet_loss_percent": 0.8, "command_rate_hz": 0.2
        }
        res = self.pipeline.process_packet(p)
        self.assertFalse(res["is_anomaly"])
        self.assertEqual(res["category"], "nominal")

if __name__ == "__main__":
    unittest.main()
